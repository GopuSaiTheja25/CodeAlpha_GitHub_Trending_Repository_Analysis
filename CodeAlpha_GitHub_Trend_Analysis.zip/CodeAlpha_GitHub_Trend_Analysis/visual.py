import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("github_trending.csv")

language_counts = df["Language"].value_counts()

plt.figure(figsize=(10,6))

language_counts.head(10).plot(kind="bar")

plt.title("Top Trending Languages")

plt.xlabel("Language")

plt.ylabel("Repositories")

plt.tight_layout()

plt.savefig("top_languages.png")

plt.show()