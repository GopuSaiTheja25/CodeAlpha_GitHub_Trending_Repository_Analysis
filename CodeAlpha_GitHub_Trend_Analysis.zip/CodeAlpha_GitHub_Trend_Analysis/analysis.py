# analysis.py

import pandas as pd

df = pd.read_csv("github_trending.csv")

print(df.info())

print(df.describe())

print(df["Language"].value_counts())

print(df.head())