# scraper.py

import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://github.com/trending"

headers = {
    "User-Agent": "Mozilla/5.0"
}

response = requests.get(url, headers=headers)

soup = BeautifulSoup(response.text, "html.parser")

repositories = []

for repo in soup.find_all("article", class_="Box-row"):

    try:
        name = repo.h2.text.strip().replace("\n", "")

        language = repo.find("span", itemprop="programmingLanguage")

        language = language.text if language else "Unknown"

        stars = repo.find_all("a")[-2].text.strip()

        repositories.append([
            name,
            language,
            stars
        ])

    except:
        pass

df = pd.DataFrame(
    repositories,
    columns=["Repository", "Language", "Stars"]
)

df.to_csv(
    "github_trending.csv",
    index=False
)

print(df.head())