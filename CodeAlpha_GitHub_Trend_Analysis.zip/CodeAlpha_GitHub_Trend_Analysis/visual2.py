import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("github_trending.csv")

language_counts = df["Language"].value_counts()

plt.figure(figsize=(8,8))

language_counts.head(5).plot(
    kind="pie",
    autopct="%1.1f%%"
)

plt.ylabel("")
plt.title("Language Distribution")

plt.show()